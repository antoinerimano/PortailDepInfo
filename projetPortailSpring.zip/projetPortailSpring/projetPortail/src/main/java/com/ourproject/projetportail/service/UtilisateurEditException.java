package com.ourproject.projetportail.service;

public class UtilisateurEditException extends Exception{
    public UtilisateurEditException(String s){
    }
}
