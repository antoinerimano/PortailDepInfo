package com.ourproject.projetportail.service;

import com.ourproject.projetportail.entities.Etudiant;
import com.ourproject.projetportail.entities.EtudiantDifficulte;
import com.ourproject.projetportail.entities.NoteCour;
import com.ourproject.projetportail.repos.EtudiantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EtudiantService {

    @Autowired
    EtudiantRepository repo;

    public Etudiant findEtudiantByCodeP(Integer codeP) {
        return repo.getEtudiantByCodeP(codeP);
    }

}
