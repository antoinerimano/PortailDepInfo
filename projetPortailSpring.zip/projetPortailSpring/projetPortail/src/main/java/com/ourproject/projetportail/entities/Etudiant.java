package com.ourproject.projetportail.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name="etudiant")
public class Etudiant{
    //DECLARATION ATTRIBUTES
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idEtudiant;
    @Column(nullable = false)
    private Integer codeP;

    @Column(length = 100, nullable = false)
    private String programme;

    @Column(length = 100, nullable = false)
    private String type;//normal,tuteur,etudiantDifficulte

    @Column(nullable = false)
    private Boolean ancien;

    //CONSTRUCTORS


    public Etudiant() {
    }

    public Etudiant(Integer codeP, String programme, String type) {
        this.codeP = codeP;
        this.programme = programme;
        this.type = type;
        this.ancien = false;
    }

    public Etudiant(Integer codeP, String programme, String type, Boolean ancien) {
        this.codeP = codeP;
        this.programme = programme;
        this.type = type;
        this.ancien = ancien;
    }


    //GET SET

    public Integer getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(Integer idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public Integer getCodeP() {
        return codeP;
    }

    public void setCodeP(Integer codeP) {
        this.codeP = codeP;
    }

    public String getProgramme() {
        return programme;
    }

    public void setProgramme(String programme) {
        this.programme = programme;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getAncien() {
        return ancien;
    }

    public void setAncien(Boolean ancien) {
        this.ancien = ancien;
    }


    //TO STRING

    @Override
    public String toString() {
        return "Etudiant{" +
                "idEtudiant=" + idEtudiant +
                ", codeP=" + codeP +
                ", programme='" + programme + '\'' +
                ", type='" + type + '\'' +
                ", ancien=" + ancien +
                '}';
    }
}
