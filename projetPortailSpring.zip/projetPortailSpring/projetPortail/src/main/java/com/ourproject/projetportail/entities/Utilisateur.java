package com.ourproject.projetportail.entities;

import jakarta.persistence.Entity;

import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name="utilisateur")
public class Utilisateur {
    //DECLARATION ATTRIBUTES
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idUtilisateur;

    @Column(nullable = false)
    private Integer codePermanent;

    @Column(length = 100)
    private String username;

    @Column(length = 100)
    private String password;

    @Column(length = 64)
    private String nom;

    @Column(length = 64)
    private String prenom;

    @Column(name = "dateNaissance")
    @Temporal(TemporalType.DATE)
    private String dateNaissance;

    @Column(length=64)
    private String type;



    //CONSTRUCTOR

    public Utilisateur() {
    }

    public Utilisateur(Integer codePermanent, String username, String password, String type) {
        this.codePermanent = codePermanent;
        this.username = username;
        this.password = password;
        this.type = type;
    }

    public Utilisateur(Integer codePermanent, String username, String password, String nom, String prenom, String dateNaissance) {
        this.codePermanent = codePermanent;
        this.username = username;
        this.password = password;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
    }


    //GET AND SET
    public Integer getIdUtilisateur() {
        return idUtilisateur;
    }

    public void setIdUtilisateur(Integer idUtilisateur) {
        this.idUtilisateur = idUtilisateur;
    }

    public Integer getCodePermanent() {
        return codePermanent;
    }

    public void setCodePermanent(Integer codePermanent) {
        this.codePermanent = codePermanent;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    //---TO STRING

    @Override
    public String toString() {
        return "Utilisateur{" +
                "idUtilisateur=" + idUtilisateur +
                ", codePermanent=" + codePermanent +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", dateNaissance='" + dateNaissance + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
