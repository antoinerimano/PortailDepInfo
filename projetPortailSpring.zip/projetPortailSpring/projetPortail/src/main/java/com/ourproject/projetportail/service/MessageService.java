package com.ourproject.projetportail.service;

import org.springframework.stereotype.Service;

@Service
public class MessageService {
}
