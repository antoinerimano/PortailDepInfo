package com.ourproject.projetportail.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name="professeur")
public class Professeur{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idProfesseur;

    @Column(nullable = false)
    private Integer codeP;
    @Column(length = 100, nullable = false)
    private String departement;//like, programmation or reseautique or smt else

    @Column(length=100,nullable=true)
    private String email;

    //private Cour cours;

    //CONSTRUCTOR

    public Professeur() {
    }

    public Professeur(Integer codeP, String departement,String email) {
        this.codeP = codeP;
        this.departement = departement;
        this.email = email;
    }
    //GET SET

    public Integer getIdProfesseur() {
        return idProfesseur;
    }

    public void setIdProfesseur(Integer idProfesseur) {
        this.idProfesseur = idProfesseur;
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public Integer getCodeP() {
        return codeP;
    }

    public void setCodeP(Integer codeP) {
        this.codeP = codeP;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    //TO STRING

    @Override
    public String toString() {
        return "Professeur{" +
                "idProfesseur=" + idProfesseur +
                ", codeP=" + codeP +
                ", departement='" + departement + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
