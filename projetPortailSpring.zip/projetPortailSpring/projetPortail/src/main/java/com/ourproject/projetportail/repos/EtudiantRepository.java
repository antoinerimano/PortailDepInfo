package com.ourproject.projetportail.repos;

import com.ourproject.projetportail.entities.Etudiant;
import com.ourproject.projetportail.entities.Utilisateur;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EtudiantRepository extends CrudRepository<Etudiant, Integer> {

    @Query("SELECT u FROM Etudiant u WHERE u.codeP = :codeP")
    //@Param est utilisé pour lier le paramètre method au paramètre Query.
    public Etudiant getEtudiantByCodeP(@Param("codeP") Integer codeP);

}
