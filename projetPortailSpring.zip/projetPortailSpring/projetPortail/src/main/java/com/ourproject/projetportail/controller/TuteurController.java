package com.ourproject.projetportail.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TuteurController {
}
