package com.ourproject.projetportail.service;

public class NoteEditException extends Exception{
    public NoteEditException(String s){
    }

}
