package com.ourproject.projetportail.repos;

import com.ourproject.projetportail.entities.NoteCour;
import com.ourproject.projetportail.entities.Tuteur;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TuteurRepository extends CrudRepository<Tuteur,Integer> {
}
