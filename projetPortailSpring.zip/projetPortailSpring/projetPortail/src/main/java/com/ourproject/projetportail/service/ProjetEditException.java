package com.ourproject.projetportail.service;

public class ProjetEditException extends Exception{
    public ProjetEditException(String s){
    }
}
