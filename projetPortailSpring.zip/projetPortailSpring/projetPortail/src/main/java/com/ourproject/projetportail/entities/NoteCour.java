package com.ourproject.projetportail.entities;

import jakarta.persistence.*;

@Entity
@Table(name="notecour")
public class NoteCour {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idNotecours;
    @Column(length = 100, nullable = false)
    private String nomNoteCour;
    @Column(length = 100, nullable = false)
    private String codeCour;
    @Column(length = 400, nullable = false)
    private String lien;
    @Column(name = "dateDeCreation")
    @Temporal(TemporalType.DATE)
    private String dateDeCreation;
    @Column(nullable = false)
    private int codeP;

    //CONSTRUCTOR

    public NoteCour() {
    }

    public NoteCour(String nomNoteCour, String codeCour, String lien, String dateDeCreation, int codeP) {
        this.nomNoteCour = nomNoteCour;
        this.codeCour = codeCour;
        this.lien = lien;
        this.dateDeCreation = dateDeCreation;
        this.codeP = codeP;
    }
    //GET SET

    public int getIdNotecours() {
        return idNotecours;
    }

    public void setIdNotecours(int idNotecours) {
        this.idNotecours = idNotecours;
    }

    public String getNomNoteCour() {
        return nomNoteCour;
    }

    public void setNomNoteCour(String nomNoteCour) {
        this.nomNoteCour = nomNoteCour;
    }

    public String getCodeCour() {
        return codeCour;
    }

    public void setCodeCour(String codeCour) {
        this.codeCour = codeCour;
    }

    public String getLien() {
        return lien;
    }

    public void setLien(String lien) {
        this.lien = lien;
    }

    public int getCodeP() {
        return codeP;
    }

    public void setCodeP(int codeP) {
        this.codeP = codeP;
    }

    public String getDateDeCreation() {
        return dateDeCreation;
    }

    public void setDateDeCreation(String dateDeCreation) {
        this.dateDeCreation = dateDeCreation;
    }

    //TO STRING

    @Override
    public String toString() {
        return "NoteCour{" +
                "idNotecours=" + idNotecours +
                ", nomNoteCour='" + nomNoteCour + '\'' +
                ", codeCour='" + codeCour + '\'' +
                ", lien='" + lien + '\'' +
                ", dateDeCreation='" + dateDeCreation + '\'' +
                ", codeP=" + codeP +
                '}';
    }
}
