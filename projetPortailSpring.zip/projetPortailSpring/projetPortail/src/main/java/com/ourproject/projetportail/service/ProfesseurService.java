package com.ourproject.projetportail.service;

import com.ourproject.projetportail.entities.Etudiant;
import com.ourproject.projetportail.entities.Professeur;
import com.ourproject.projetportail.entities.Utilisateur;
import com.ourproject.projetportail.repos.ProfesseurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfesseurService {

    @Autowired
    ProfesseurRepository repo;

    public Professeur findProfesseurByCodeP(Integer codeP) {
        Professeur prof;
        try{
            prof = repo.getProfesseurByCodeP(codeP);
        }catch(Exception e){
            System.out.println("There was an error fetching the mail of the teacher");
            prof=null;
            return prof;
        }
        return prof;
    }

}
